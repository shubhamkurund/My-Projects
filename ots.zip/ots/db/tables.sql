CREATE TABLE tbladmin
(
    ID serial primary KEY,
    AdminName varchar(120) NOT NULL,
    UserName varchar(120) NOT NULL,
    MobileNumber varchar(15) NOT NULL,
    Email varchar(120) NOT NULL,
    Password varchar(120) NOT NULL,
    AdminRegdate timestamp DEFAULT current_timestamp
);

INSERT INTO tbladmin(AdminName, UserName, MobileNumber, Email, Password) VALUES
('Harshada', 'admin', '9309793200', 'adminuser@gmail.com', 'admin');


CREATE TABLE tbluser 
(
  ID serial PRIMARY KEY,
  FullName varchar(200) NOT NULL,
  MobileNumber varchar(15) NOT NULL,
  Email varchar(200) NOT NULL,
  Password varchar(200) NOT NULL,
  RegDate timestamp DEFAULT current_timestamp
);


INSERT INTO tbluser(FullName, MobileNumber, Email, Password) VALUES
('Akshay Kumar', '8985858585', 'akshay2022@gmail.com', 'akshay'),
('Aishwarya Rai', '9544644654', 'aish.rai@gmail.com', 'aish2022'),
('Sachin Tendulkar', '9234567890', 'sach2021@gmail.com', 'sach22');


CREATE TABLE tbltiffin (
  ID serial primary KEY,
  Type varchar(120) NOT NULL,
  Title varchar(200) NOT NULL,
  Description text NOT NULL,
  Cost float NOT NULL,
  Image varchar(120) NOT NULL,
  PostDate timestamp DEFAULT current_timestamp
);

INSERT INTO tbltiffin(Type, Title, Description, Cost, Image) VALUES
('Veg', 'Small Veg Tiffin', 'It contains\r\n1. One Sabji\r\n2. Six Poori', 50, 'bfa6998622fb031e5771edf658186a3e1580901204.jpg'),
('Veg', 'Medium Veg Tiffin', 'It contains\r\n1. Four Roti\r\n2. One Dal\r\n3. Two Sabji\r\n4. Pickle', 75, '7fdc1a630c238af0815181f9faa190f51580901298.jpg'),
('Veg', 'Large Veg Tiffin', 'It contains\r\n1. Four Roti\r\n2. Rice\r\n3. One Sabji\r\n4.Raita\r\n5. Salad\r\n6.Pickle', 120, '19c10f4e66067da4b5eb1dac874e46721580901461.jpg'),
('Non Veg', 'Small Non Veg Tiffin', 'It contains\r\n1. Four Roti\r\n2. Two Missi Roti\r\n3. One Dal\r\n4. Two Sabji\r\n5. Salad\r\n6. Pickles\r\n7. Raita\r\n8. Sweets', 200, '7fdc1a630c238af0815181f9faa190f51580901580.jpg'),
('Non Veg', 'Medium Non Veg Tiffin', 'It contains\r\n1. Four Roti\r\n2. Rice\r\n3. One Sabji\r\n4.Raita\r\n5. Salad\r\n6.Pickle', 250, 'efc1a80c391be252d7d777a437f868701580470642.jpg'),
('Non Veg', 'Large Non Veg Tiffin', 'It contains\r\n1. Four Roti\r\n2. Rice\r\n3. One Sabji\r\n4.Raita\r\n5. Salad\r\n6.Pickle\r\n', 350, '74375080377499ab76dad37484ee7f151580881251.jpg');


CREATE TABLE tblorder(
  ID serial PRIMARY KEY,
  TiffinID int references tbltiffin(id) on delete cascade,
  UserID int references tbluser(id) on delete cascade,
  OrderNumber int DEFAULT NULL,
  FullName varchar(120) NOT NULL,
  Email varchar(200) NOT NULL,
  MobileNumber varchar(15) NOT NULL,
  Quantity int NOT NULL,
  FromDate varchar(200) NOT NULL,
  ToDate varchar(200) NOT NULL,
  Time varchar(50) NOT NULL,
  Address text NOT NULL,
  OrderDate timestamp DEFAULT current_timestamp,
  TotalCost varchar(200) NOT NULL,
  Remark varchar(200) NOT NULL,
  Status varchar(50) NOT NULL,
  UpdationDate timestamp DEFAULT current_timestamp
);

INSERT INTO tblorder (TiffinID, UserID, OrderNumber, FullName, Email, MobileNumber, Quantity, FromDate, ToDate, Time, Address, OrderDate, TotalCost, Remark, Status) VALUES
(2, 2, 750169391, 'Aishwarya Rai', 'aish.rai@gmail.com', '9544644654', 2, '2022-05-15', '2020-05-31', '23:12', 'Pimpri Pune 17', '2022-05-06 15:33:31', '2400', 'Confirmed', 'Confirmed'),
(1, 3, 741712845, 'Sachin Tendulkar', 'sach2021@gmail.com', 9234567890, 1, '2022-05-15', '2020-05-25', '08:00', 'Akurdi Pune 35', '2020-03-06 15:51:20', '500', 'Order Confirmed', 'Confirmed');

CREATE TABLE tblpage (
  ID serial primary KEY,
  PageType varchar(120) NOT NULL,
  PageTitle text NOT NULL,
  PageDescription text NOT NULL,
  Email varchar(200) DEFAULT NULL,
  MobileNumber varchar(15) DEFAULT NULL,
  UpdationDate timestamp DEFAULT current_timestamp
);

INSERT INTO tblpage (PageType, PageTitle, PageDescription, Email, MobileNumber) VALUES
('aboutus', 'About Us', '<span style=\"color: rgb(0, 0, 0); font-family: \" pt=\"\" sans\",=\"\" sans-serif;\"=\"\">Its an online-cum-offline tiffin service company that offers high quality healthy and delicious meal plans for homes and offices. With a seamless blend of advanced nutrition, food science and food service, it offers wellness meals and calorie-defined meals that are in accordance with the customer preferences.</span><div><br></div><div>ytest<br style=\"-webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(0, 0, 0); font-family: \" pt=\"\" sans\",=\"\" sans-serif;\"=\"\"><br></div>', NULL, NULL),
('contactus', 'Contact Us', 'D-204, Sadashiv Peth, Pune-411005,India', 'info@gmail.com', '8529631232');




