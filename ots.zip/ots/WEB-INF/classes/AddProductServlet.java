import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.sql.*;
 
@WebServlet("/AddProductServlet")
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB
public class AddProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();	
		try{
			HttpSession session = request.getSession(true);

		   	String appPath = request.getServletContext().getRealPath("/");

			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ots","postgres","test");

	   		String adminid=session.getAttribute("otssaid").toString();
	 
	  		String type=request.getParameter("type");
	  		String title=request.getParameter("title");
	  		String desc=request.getParameter("desc");
	  		String cost=request.getParameter("cost");

	  		String fileName = "";
		   	for(Part part : request.getParts()){
		    	fileName = extractFileName(part);

			    if(!fileName.equals(""))
			    {
	            	part.write(appPath + "admin/images/"+fileName);
	            	break;
			    }
		    }

			String sql="insert into tbltiffin(Type,Title,Description,Cost,Image)values('"+type+"','"+title+"','"+desc+"',"+cost+",'"+fileName+"')";

		   	if(con.createStatement().executeUpdate(sql)==1) {
		    	out.print("<script>alert('Tiffin detail has been added.')</script>");
		  	}
		  	else{
		      	out.print("<script>alert('Something Went Wrong. Please try again')</script>");
		    }
			out.print("<script>window.location.href ='http://localhost:8080/ots/admin/add-tiffin.jsp'</script>");
		}
		catch(Exception e){
			out.println("<h4>"+e+"</h4>");
		}	
    }
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }
}
