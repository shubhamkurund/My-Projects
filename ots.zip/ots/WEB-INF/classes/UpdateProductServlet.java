import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.sql.*;
 
@WebServlet("/UpdateProductServlet")
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB
public class UpdateProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();	

		try{
			HttpSession session = request.getSession(true);

	        String appPath = request.getServletContext().getRealPath("/");

			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ots","postgres","test");

			String eid=session.getAttribute("editid").toString();
			ResultSet rs = con.createStatement().executeQuery("select image from tbltiffin where id="+eid);
			rs.next();
			String pimg = rs.getString(1);
			String fileName = "";

	        for (Part part : request.getParts()) {
	            fileName = extractFileName(part);

		    	if(!fileName.equals("")){
					java.io.File d = new java.io.File(appPath + "admin/images/"+pimg);
					d.delete();
                    part.write(appPath + "admin/images/"+fileName);
					pimg = fileName;
					break;
		    	}
	        }

			con.createStatement().executeUpdate("update tbltiffin set image='"+pimg+"' where id="+eid);
			out.print("<script>alert('Food Image has been updated')</script>");
			out.print("<script>window.location.href ='http://localhost:8080/ots/admin/manage-tiffin.jsp'</script>");
		}
		catch(Exception e){
			out.println("<h4>"+e+"</h4>");
		}	
    }
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }
}
